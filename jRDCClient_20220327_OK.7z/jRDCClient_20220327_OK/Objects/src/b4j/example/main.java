package b4j.example;


import anywheresoftware.b4a.BA;

public class main extends javafx.application.Application{
public static main mostCurrent = new main();

public static BA ba;
static {
		ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.main", null);
		ba.loadHtSubs(main.class);
        if (ba.getClass().getName().endsWith("ShellBA")) {
			
			ba.raiseEvent2(null, true, "SHELL", false);
			ba.raiseEvent2(null, true, "CREATE", true, "b4j.example.main", ba);
		}
	}
    public static Class<?> getObject() {
		return main.class;
	}

 
    public static void main(String[] args) {
    	launch(args);
    }
    public void start (javafx.stage.Stage stage) {
        try {
            if (!false)
                System.setProperty("prism.lcdtext", "false");
            anywheresoftware.b4j.objects.FxBA.application = this;
		    anywheresoftware.b4a.keywords.Common.setDensity(javafx.stage.Screen.getPrimary().getDpi());
            anywheresoftware.b4a.keywords.Common.LogDebug("Program started.");
            initializeProcessGlobals();
            anywheresoftware.b4j.objects.Form frm = new anywheresoftware.b4j.objects.Form();
            frm.initWithStage(ba, stage, 500, 500);
            ba.raiseEvent(null, "appstart", frm, (String[])getParameters().getRaw().toArray(new String[0]));
        } catch (Throwable t) {
            BA.printException(t, true);
            System.exit(1);
        }
    }
public static anywheresoftware.b4a.keywords.Common __c = null;
public static String _rdclink = "";
public static anywheresoftware.b4j.objects.JFX _fx = null;
public static anywheresoftware.b4j.objects.Form _mainform = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper _button1 = null;
public static anywheresoftware.b4j.objects.TableViewWrapper _tableview1 = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper _pane1 = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper _button2 = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper _button3 = null;
public static b4j.example.jrdc2utils _jrdc2utils = null;
public static b4j.example.httputils2service _httputils2service = null;
public static class _dbresult{
public boolean IsInitialized;
public Object Tag;
public anywheresoftware.b4a.objects.collections.Map Columns;
public anywheresoftware.b4a.objects.collections.List Rows;
public void Initialize() {
IsInitialized = true;
Tag = new Object();
Columns = new anywheresoftware.b4a.objects.collections.Map();
Rows = new anywheresoftware.b4a.objects.collections.List();
}
@Override
		public String toString() {
			return BA.TypeToString(this, false);
		}}
public static class _dbcommand{
public boolean IsInitialized;
public String Name;
public Object[] Parameters;
public void Initialize() {
IsInitialized = true;
Name = "";
Parameters = new Object[0];
{
int d0 = Parameters.length;
for (int i0 = 0;i0 < d0;i0++) {
Parameters[i0] = new Object();
}
}
;
}
@Override
		public String toString() {
			return BA.TypeToString(this, false);
		}}
public static String  _appstart(anywheresoftware.b4j.objects.Form _form1,String[] _args) throws Exception{
 //BA.debugLineNum = 26;BA.debugLine="Sub AppStart (Form1 As Form, Args() As String)";
 //BA.debugLineNum = 27;BA.debugLine="MainForm = Form1";
_mainform = _form1;
 //BA.debugLineNum = 28;BA.debugLine="MainForm.RootPane.LoadLayout(\"Layout1\")";
_mainform.getRootPane().LoadLayout(ba,"Layout1");
 //BA.debugLineNum = 29;BA.debugLine="MainForm.Show";
_mainform.Show();
 //BA.debugLineNum = 31;BA.debugLine="MainForm.AlwaysOnTop = True";
_mainform.setAlwaysOnTop(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 35;BA.debugLine="TableView1.SetColumns(Array(\"col1\",\"col2\"))";
_tableview1.SetColumns(anywheresoftware.b4a.keywords.Common.ArrayToList(new Object[]{(Object)("col1"),(Object)("col2")}));
 //BA.debugLineNum = 38;BA.debugLine="End Sub";
return "";
}
public static void  _button1_click() throws Exception{
ResumableSub_Button1_Click rsub = new ResumableSub_Button1_Click(null);
rsub.resume(ba, null);
}
public static class ResumableSub_Button1_Click extends BA.ResumableSub {
public ResumableSub_Button1_Click(b4j.example.main parent) {
this.parent = parent;
}
b4j.example.main parent;
anywheresoftware.b4a.objects.collections.List _cmdlist = null;
int _result = 0;
b4j.example.main._dbcommand _cmd = null;
b4j.example.main._dbresult _res = null;
anywheresoftware.b4a.objects.collections.List _vatnolst = null;
int _i = 0;
int step38;
int limit38;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 64;BA.debugLine="jRDC2Utils.Intitialize(rdcLink)";
parent._jrdc2utils._intitialize /*String*/ (parent._rdclink);
 //BA.debugLineNum = 67;BA.debugLine="Log(\"建立資料表==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("3262156","建立資料表==>",0);
 //BA.debugLineNum = 68;BA.debugLine="Dim cmdList As List";
_cmdlist = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 69;BA.debugLine="cmdList.Initialize";
_cmdlist.Initialize();
 //BA.debugLineNum = 70;BA.debugLine="cmdList.Clear";
_cmdlist.Clear();
 //BA.debugLineNum = 72;BA.debugLine="jRDC2Utils.AddCommand(cmdList, \"CreateTable_artic";
parent._jrdc2utils._addcommand /*String*/ (_cmdlist,"CreateTable_article",new Object[]{});
 //BA.debugLineNum = 73;BA.debugLine="Wait For (jRDC2Utils.ExecuteCommands(cmdList)) co";
anywheresoftware.b4a.keywords.Common.WaitFor("complete", ba, this, parent._jrdc2utils._executecommands /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_cmdlist));
this.state = 23;
return;
case 23:
//C
this.state = 1;
_result = (int) result[0];
;
 //BA.debugLineNum = 76;BA.debugLine="If Result >0 Then";
if (true) break;

case 1:
//if
this.state = 6;
if (_result>0) { 
this.state = 3;
}else {
this.state = 5;
}if (true) break;

case 3:
//C
this.state = 6;
 //BA.debugLineNum = 77;BA.debugLine="Log(\"建立資料表:成功\")";
anywheresoftware.b4a.keywords.Common.LogImpl("3262166","建立資料表:成功",0);
 if (true) break;

case 5:
//C
this.state = 6;
 //BA.debugLineNum = 79;BA.debugLine="Log(\"建立資料表:失敗\")";
anywheresoftware.b4a.keywords.Common.LogImpl("3262168","建立資料表:失敗",0);
 if (true) break;

case 6:
//C
this.state = 7;
;
 //BA.debugLineNum = 82;BA.debugLine="Log(\"刪除資料==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("3262171","刪除資料==>",0);
 //BA.debugLineNum = 83;BA.debugLine="cmdList.Clear";
_cmdlist.Clear();
 //BA.debugLineNum = 84;BA.debugLine="jRDC2Utils.AddCommand(cmdList,\"delete_article\",Ar";
parent._jrdc2utils._addcommand /*String*/ (_cmdlist,"delete_article",new Object[]{});
 //BA.debugLineNum = 85;BA.debugLine="wait for (jRDC2Utils.ExecuteCommands(cmdList)) co";
anywheresoftware.b4a.keywords.Common.WaitFor("complete", ba, this, parent._jrdc2utils._executecommands /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_cmdlist));
this.state = 24;
return;
case 24:
//C
this.state = 7;
_result = (int) result[0];
;
 //BA.debugLineNum = 87;BA.debugLine="If Result >0 Then";
if (true) break;

case 7:
//if
this.state = 12;
if (_result>0) { 
this.state = 9;
}else {
this.state = 11;
}if (true) break;

case 9:
//C
this.state = 12;
 //BA.debugLineNum = 88;BA.debugLine="Log(\"刪除資料:成功\")";
anywheresoftware.b4a.keywords.Common.LogImpl("3262177","刪除資料:成功",0);
 if (true) break;

case 11:
//C
this.state = 12;
 //BA.debugLineNum = 90;BA.debugLine="Log(\"刪除資料:失敗\")";
anywheresoftware.b4a.keywords.Common.LogImpl("3262179","刪除資料:失敗",0);
 if (true) break;

case 12:
//C
this.state = 13;
;
 //BA.debugLineNum = 94;BA.debugLine="Log(\"新增資料==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("3262183","新增資料==>",0);
 //BA.debugLineNum = 95;BA.debugLine="cmdList.Clear";
_cmdlist.Clear();
 //BA.debugLineNum = 97;BA.debugLine="jRDC2Utils.AddCommand(cmdList,\"insert_article\",Ar";
parent._jrdc2utils._addcommand /*String*/ (_cmdlist,"insert_article",new Object[]{(Object)(1),(Object)("a1")});
 //BA.debugLineNum = 98;BA.debugLine="jRDC2Utils.AddCommand(cmdList,\"insert_article\",Ar";
parent._jrdc2utils._addcommand /*String*/ (_cmdlist,"insert_article",new Object[]{(Object)(2),(Object)("a2")});
 //BA.debugLineNum = 100;BA.debugLine="wait for (jRDC2Utils.ExecuteCommands(cmdList)) co";
anywheresoftware.b4a.keywords.Common.WaitFor("complete", ba, this, parent._jrdc2utils._executecommands /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_cmdlist));
this.state = 25;
return;
case 25:
//C
this.state = 13;
_result = (int) result[0];
;
 //BA.debugLineNum = 102;BA.debugLine="If Result >0 Then";
if (true) break;

case 13:
//if
this.state = 18;
if (_result>0) { 
this.state = 15;
}else {
this.state = 17;
}if (true) break;

case 15:
//C
this.state = 18;
 //BA.debugLineNum = 103;BA.debugLine="Log(\"新增資料:成功\")";
anywheresoftware.b4a.keywords.Common.LogImpl("3262192","新增資料:成功",0);
 if (true) break;

case 17:
//C
this.state = 18;
 //BA.debugLineNum = 105;BA.debugLine="Log(\"新增資料:失敗\")";
anywheresoftware.b4a.keywords.Common.LogImpl("3262194","新增資料:失敗",0);
 if (true) break;

case 18:
//C
this.state = 19;
;
 //BA.debugLineNum = 108;BA.debugLine="Log(\"查詢資料==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("3262197","查詢資料==>",0);
 //BA.debugLineNum = 109;BA.debugLine="cmdList.Clear";
_cmdlist.Clear();
 //BA.debugLineNum = 110;BA.debugLine="Dim cmd As DBCommand=jRDC2Utils.CreateCommand(\"se";
_cmd = parent._jrdc2utils._createcommand /*b4j.example.main._dbcommand*/ ("select_article",new Object[]{});
 //BA.debugLineNum = 111;BA.debugLine="Wait For(jRDC2Utils.ExecuteQuery(cmd)) complete(r";
anywheresoftware.b4a.keywords.Common.WaitFor("complete", ba, this, parent._jrdc2utils._executequery /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_cmd));
this.state = 26;
return;
case 26:
//C
this.state = 19;
_res = (b4j.example.main._dbresult) result[0];
;
 //BA.debugLineNum = 112;BA.debugLine="Dim vatNoLst As List";
_vatnolst = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 113;BA.debugLine="vatNoLst.Initialize";
_vatnolst.Initialize();
 //BA.debugLineNum = 114;BA.debugLine="For i=0 To res.Rows.Size-1";
if (true) break;

case 19:
//for
this.state = 22;
step38 = 1;
limit38 = (int) (_res.Rows /*anywheresoftware.b4a.objects.collections.List*/ .getSize()-1);
_i = (int) (0) ;
this.state = 27;
if (true) break;

case 27:
//C
this.state = 22;
if ((step38 > 0 && _i <= limit38) || (step38 < 0 && _i >= limit38)) this.state = 21;
if (true) break;

case 28:
//C
this.state = 27;
_i = ((int)(0 + _i + step38)) ;
if (true) break;

case 21:
//C
this.state = 28;
 //BA.debugLineNum = 115;BA.debugLine="vatNoLst.Add(jRDC2Utils.GetColumnObject(res,i,\"c";
_vatnolst.Add(parent._jrdc2utils._getcolumnobject /*Object*/ (_res,_i,"col2"));
 //BA.debugLineNum = 117;BA.debugLine="Log(\"col1= \"&jRDC2Utils.GetColumnObject(res,i,\"c";
anywheresoftware.b4a.keywords.Common.LogImpl("3262206","col1= "+BA.ObjectToString(parent._jrdc2utils._getcolumnobject /*Object*/ (_res,_i,"col1")),0);
 //BA.debugLineNum = 118;BA.debugLine="Log(\"col2= \"&jRDC2Utils.GetColumnObject(res,i,\"c";
anywheresoftware.b4a.keywords.Common.LogImpl("3262207","col2= "+BA.ObjectToString(parent._jrdc2utils._getcolumnobject /*Object*/ (_res,_i,"col2")),0);
 if (true) break;
if (true) break;

case 22:
//C
this.state = -1;
;
 //BA.debugLineNum = 121;BA.debugLine="jRDC2Utils.ExecuteTableView(cmd,TableView1)";
parent._jrdc2utils._executetableview /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_cmd,parent._tableview1);
 //BA.debugLineNum = 124;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public static void  _complete(int _result) throws Exception{
}
public static void  _button2_click() throws Exception{
ResumableSub_Button2_Click rsub = new ResumableSub_Button2_Click(null);
rsub.resume(ba, null);
}
public static class ResumableSub_Button2_Click extends BA.ResumableSub {
public ResumableSub_Button2_Click(b4j.example.main parent) {
this.parent = parent;
}
b4j.example.main parent;
anywheresoftware.b4a.objects.collections.List _cmdlist = null;
int _result = 0;
b4j.example.main._dbcommand _cmd1 = null;
b4j.example.httpjob _j = null;
anywheresoftware.b4a.objects.streams.File.InputStreamWrapper _inputstream1 = null;
anywheresoftware.b4a.objects.streams.File.OutputStreamWrapper _outputstream1 = null;
byte[] _buffer = null;
b4j.example.main._dbcommand _cmd2 = null;
b4j.example.dbrequestmanager _req = null;
b4j.example.main._dbcommand _cmd = null;
b4j.example.main._dbresult _res = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 155;BA.debugLine="jRDC2Utils.Intitialize(rdcLink)";
parent._jrdc2utils._intitialize /*String*/ (parent._rdclink);
 //BA.debugLineNum = 177;BA.debugLine="Log(\"建立資料表==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("3327708","建立資料表==>",0);
 //BA.debugLineNum = 178;BA.debugLine="Dim cmdList As List";
_cmdlist = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 179;BA.debugLine="cmdList.Initialize";
_cmdlist.Initialize();
 //BA.debugLineNum = 180;BA.debugLine="cmdList.Clear";
_cmdlist.Clear();
 //BA.debugLineNum = 182;BA.debugLine="jRDC2Utils.AddCommand(cmdList, \"CreateTable_artic";
parent._jrdc2utils._addcommand /*String*/ (_cmdlist,"CreateTable_article",new Object[]{});
 //BA.debugLineNum = 183;BA.debugLine="Wait For (jRDC2Utils.ExecuteCommands(cmdList)) co";
anywheresoftware.b4a.keywords.Common.WaitFor("complete", ba, this, parent._jrdc2utils._executecommands /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_cmdlist));
this.state = 21;
return;
case 21:
//C
this.state = 1;
_result = (int) result[0];
;
 //BA.debugLineNum = 186;BA.debugLine="If Result >0 Then";
if (true) break;

case 1:
//if
this.state = 6;
if (_result>0) { 
this.state = 3;
}else {
this.state = 5;
}if (true) break;

case 3:
//C
this.state = 6;
 //BA.debugLineNum = 187;BA.debugLine="Log(\"建立資料表:成功\")";
anywheresoftware.b4a.keywords.Common.LogImpl("3327718","建立資料表:成功",0);
 if (true) break;

case 5:
//C
this.state = 6;
 //BA.debugLineNum = 189;BA.debugLine="Log(\"建立資料表:失敗\")";
anywheresoftware.b4a.keywords.Common.LogImpl("3327720","建立資料表:失敗",0);
 if (true) break;

case 6:
//C
this.state = 7;
;
 //BA.debugLineNum = 192;BA.debugLine="Log(\"刪除資料==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("3327723","刪除資料==>",0);
 //BA.debugLineNum = 193;BA.debugLine="Dim cmd1 As DBCommand = CreateCommand(\"DeleteAll_";
_cmd1 = _createcommand("DeleteAll_animal",new Object[]{});
 //BA.debugLineNum = 194;BA.debugLine="Dim j As HttpJob = CreateRequest.ExecuteBatch(Arr";
_j = _createrequest()._executebatch /*b4j.example.httpjob*/ (anywheresoftware.b4a.keywords.Common.ArrayToList(new Object[]{(Object)(_cmd1)}),anywheresoftware.b4a.keywords.Common.Null);
 //BA.debugLineNum = 195;BA.debugLine="Wait For(j) JobDone(j As HttpJob)";
anywheresoftware.b4a.keywords.Common.WaitFor("jobdone", ba, this, (Object)(_j));
this.state = 22;
return;
case 22:
//C
this.state = 7;
_j = (b4j.example.httpjob) result[0];
;
 //BA.debugLineNum = 197;BA.debugLine="If j.Success Then";
if (true) break;

case 7:
//if
this.state = 10;
if (_j._success /*boolean*/ ) { 
this.state = 9;
}if (true) break;

case 9:
//C
this.state = 10;
 //BA.debugLineNum = 198;BA.debugLine="Log(\"刪除資料:成功\")";
anywheresoftware.b4a.keywords.Common.LogImpl("3327729","刪除資料:成功",0);
 if (true) break;

case 10:
//C
this.state = 11;
;
 //BA.debugLineNum = 200;BA.debugLine="j.Release";
_j._release /*String*/ ();
 //BA.debugLineNum = 202;BA.debugLine="Log(\"新增資料==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("3327733","新增資料==>",0);
 //BA.debugLineNum = 204;BA.debugLine="Private InputStream1 As InputStream";
_inputstream1 = new anywheresoftware.b4a.objects.streams.File.InputStreamWrapper();
 //BA.debugLineNum = 205;BA.debugLine="InputStream1 = File.OpenInput(File.DirApp , \"keys";
_inputstream1 = anywheresoftware.b4a.keywords.Common.File.OpenInput(anywheresoftware.b4a.keywords.Common.File.getDirApp(),"keys.png");
 //BA.debugLineNum = 206;BA.debugLine="Private OutputStream1 As OutputStream";
_outputstream1 = new anywheresoftware.b4a.objects.streams.File.OutputStreamWrapper();
 //BA.debugLineNum = 207;BA.debugLine="OutputStream1.InitializeToBytesArray(1000)";
_outputstream1.InitializeToBytesArray((int) (1000));
 //BA.debugLineNum = 208;BA.debugLine="File.Copy2(InputStream1, OutputStream1)";
anywheresoftware.b4a.keywords.Common.File.Copy2((java.io.InputStream)(_inputstream1.getObject()),(java.io.OutputStream)(_outputstream1.getObject()));
 //BA.debugLineNum = 209;BA.debugLine="Private Buffer() As Byte 'declares an empty array";
_buffer = new byte[(int) (0)];
;
 //BA.debugLineNum = 210;BA.debugLine="Buffer = OutputStream1.ToBytesArray";
_buffer = _outputstream1.ToBytesArray();
 //BA.debugLineNum = 212;BA.debugLine="Dim cmd1 As DBCommand = CreateCommand(\"Insert_ani";
_cmd1 = _createcommand("Insert_animal",new Object[]{(Object)("test1"),(Object)(_buffer)});
 //BA.debugLineNum = 213;BA.debugLine="Dim cmd2 As DBCommand = CreateCommand(\"Insert_ani";
_cmd2 = _createcommand("Insert_animal",new Object[]{(Object)("test2"),anywheresoftware.b4a.keywords.Common.Null});
 //BA.debugLineNum = 214;BA.debugLine="Dim j As HttpJob = CreateRequest.ExecuteBatch(Arr";
_j = _createrequest()._executebatch /*b4j.example.httpjob*/ (anywheresoftware.b4a.keywords.Common.ArrayToList(new Object[]{(Object)(_cmd1),(Object)(_cmd2)}),anywheresoftware.b4a.keywords.Common.Null);
 //BA.debugLineNum = 215;BA.debugLine="Wait For(j) JobDone(j As HttpJob)";
anywheresoftware.b4a.keywords.Common.WaitFor("jobdone", ba, this, (Object)(_j));
this.state = 23;
return;
case 23:
//C
this.state = 11;
_j = (b4j.example.httpjob) result[0];
;
 //BA.debugLineNum = 217;BA.debugLine="If j.Success Then";
if (true) break;

case 11:
//if
this.state = 14;
if (_j._success /*boolean*/ ) { 
this.state = 13;
}if (true) break;

case 13:
//C
this.state = 14;
 //BA.debugLineNum = 218;BA.debugLine="Log(\"新增資料:成功\")";
anywheresoftware.b4a.keywords.Common.LogImpl("3327749","新增資料:成功",0);
 if (true) break;

case 14:
//C
this.state = 15;
;
 //BA.debugLineNum = 220;BA.debugLine="j.Release";
_j._release /*String*/ ();
 //BA.debugLineNum = 222;BA.debugLine="Log(\"讀取資料==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("3327753","讀取資料==>",0);
 //BA.debugLineNum = 223;BA.debugLine="Dim req As DBRequestManager = CreateRequest";
_req = _createrequest();
 //BA.debugLineNum = 224;BA.debugLine="Dim cmd As DBCommand = CreateCommand(\"Select_anim";
_cmd = _createcommand("Select_animal",new Object[]{(Object)(1)});
 //BA.debugLineNum = 225;BA.debugLine="Wait For (req.ExecuteQuery(cmd, 0, Null)) JobDone";
anywheresoftware.b4a.keywords.Common.WaitFor("jobdone", ba, this, (Object)(_req._executequery /*b4j.example.httpjob*/ (_cmd,(int) (0),anywheresoftware.b4a.keywords.Common.Null)));
this.state = 24;
return;
case 24:
//C
this.state = 15;
_j = (b4j.example.httpjob) result[0];
;
 //BA.debugLineNum = 226;BA.debugLine="If j.Success Then";
if (true) break;

case 15:
//if
this.state = 20;
if (_j._success /*boolean*/ ) { 
this.state = 17;
}else {
this.state = 19;
}if (true) break;

case 17:
//C
this.state = 20;
 //BA.debugLineNum = 227;BA.debugLine="req.HandleJobAsync(j, \"req\")";
_req._handlejobasync /*void*/ (_j,"req");
 //BA.debugLineNum = 228;BA.debugLine="Wait For (req) req_Result(res As DBResult)";
anywheresoftware.b4a.keywords.Common.WaitFor("req_result", ba, this, (Object)(_req));
this.state = 25;
return;
case 25:
//C
this.state = 20;
_res = (b4j.example.main._dbresult) result[0];
;
 //BA.debugLineNum = 230;BA.debugLine="req.PrintTable(res)";
_req._printtable /*String*/ (_res);
 if (true) break;

case 19:
//C
this.state = 20;
 //BA.debugLineNum = 232;BA.debugLine="Log(\"ERROR: \" & j.ErrorMessage)";
anywheresoftware.b4a.keywords.Common.LogImpl("3327763","ERROR: "+_j._errormessage /*String*/ ,0);
 if (true) break;

case 20:
//C
this.state = -1;
;
 //BA.debugLineNum = 234;BA.debugLine="j.Release";
_j._release /*String*/ ();
 //BA.debugLineNum = 237;BA.debugLine="Log(\"查詢資料==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("3327768","查詢資料==>",0);
 //BA.debugLineNum = 239;BA.debugLine="Dim cmd As DBCommand = CreateCommand(\"SelectAll_a";
_cmd = _createcommand("SelectAll_animal",new Object[]{});
 //BA.debugLineNum = 240;BA.debugLine="ExecuteTableView(cmd)";
_executetableview(_cmd);
 //BA.debugLineNum = 243;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public static void  _jobdone(b4j.example.httpjob _j) throws Exception{
}
public static void  _req_result(b4j.example.main._dbresult _res) throws Exception{
}
public static void  _button3_click() throws Exception{
ResumableSub_Button3_Click rsub = new ResumableSub_Button3_Click(null);
rsub.resume(ba, null);
}
public static class ResumableSub_Button3_Click extends BA.ResumableSub {
public ResumableSub_Button3_Click(b4j.example.main parent) {
this.parent = parent;
}
b4j.example.main parent;
b4j.example.xyzrdc2 _rdc = null;
int _result = 0;
b4j.example.main._dbresult _res = null;
anywheresoftware.b4a.objects.collections.List _vatnolst = null;
int _i = 0;
int step42;
int limit42;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
try {

        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 335;BA.debugLine="Dim rdc As xyzRDC2";
_rdc = new b4j.example.xyzrdc2();
 //BA.debugLineNum = 338;BA.debugLine="rdc.Initialize (rdcLink)";
_rdc._initialize /*String*/ (ba,parent._rdclink);
 //BA.debugLineNum = 341;BA.debugLine="Log(\"建立資料表==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("35111816","建立資料表==>",0);
 //BA.debugLineNum = 342;BA.debugLine="rdc.ClearCommand		'cmdList as List";
_rdc._clearcommand /*String*/ ();
 //BA.debugLineNum = 343;BA.debugLine="rdc.AddCommand(\"CreateTable_article\", Array())";
_rdc._addcommand /*String*/ ("CreateTable_article",new Object[]{});
 //BA.debugLineNum = 344;BA.debugLine="Wait For (rdc.ExecuteCommands()) complete (Result";
anywheresoftware.b4a.keywords.Common.WaitFor("complete", ba, this, _rdc._executecommands /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ ());
this.state = 35;
return;
case 35:
//C
this.state = 1;
_result = (int) result[0];
;
 //BA.debugLineNum = 345;BA.debugLine="If Result >0 Then	'失敗-1,0";
if (true) break;

case 1:
//if
this.state = 6;
if (_result>0) { 
this.state = 3;
}else {
this.state = 5;
}if (true) break;

case 3:
//C
this.state = 6;
 //BA.debugLineNum = 346;BA.debugLine="Log(\"建立資料表:成功\")";
anywheresoftware.b4a.keywords.Common.LogImpl("35111821","建立資料表:成功",0);
 if (true) break;

case 5:
//C
this.state = 6;
 //BA.debugLineNum = 348;BA.debugLine="Log(\"建立資料表:失敗\")";
anywheresoftware.b4a.keywords.Common.LogImpl("35111823","建立資料表:失敗",0);
 if (true) break;

case 6:
//C
this.state = 7;
;
 //BA.debugLineNum = 351;BA.debugLine="Log(\"刪除資料==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("35111826","刪除資料==>",0);
 //BA.debugLineNum = 352;BA.debugLine="rdc.ClearCommand		'cmdList.clear";
_rdc._clearcommand /*String*/ ();
 //BA.debugLineNum = 353;BA.debugLine="rdc.AddCommand(\"delete_article\",Array())";
_rdc._addcommand /*String*/ ("delete_article",new Object[]{});
 //BA.debugLineNum = 354;BA.debugLine="wait for (rdc.ExecuteCommands()) complete (Result";
anywheresoftware.b4a.keywords.Common.WaitFor("complete", ba, this, _rdc._executecommands /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ ());
this.state = 36;
return;
case 36:
//C
this.state = 7;
_result = (int) result[0];
;
 //BA.debugLineNum = 355;BA.debugLine="If Result >0 Then	'失敗-1";
if (true) break;

case 7:
//if
this.state = 12;
if (_result>0) { 
this.state = 9;
}else {
this.state = 11;
}if (true) break;

case 9:
//C
this.state = 12;
 //BA.debugLineNum = 356;BA.debugLine="Log(\"刪除資料:成功\")";
anywheresoftware.b4a.keywords.Common.LogImpl("35111831","刪除資料:成功",0);
 if (true) break;

case 11:
//C
this.state = 12;
 //BA.debugLineNum = 358;BA.debugLine="Log(\"刪除資料:失敗\")";
anywheresoftware.b4a.keywords.Common.LogImpl("35111833","刪除資料:失敗",0);
 if (true) break;

case 12:
//C
this.state = 13;
;
 //BA.debugLineNum = 362;BA.debugLine="Log(\"新增資料==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("35111837","新增資料==>",0);
 //BA.debugLineNum = 363;BA.debugLine="rdc.ClearCommand";
_rdc._clearcommand /*String*/ ();
 //BA.debugLineNum = 364;BA.debugLine="rdc.AddCommand(\"insert_article\",Array(1,\"a1\"))";
_rdc._addcommand /*String*/ ("insert_article",new Object[]{(Object)(1),(Object)("a1")});
 //BA.debugLineNum = 365;BA.debugLine="rdc.AddCommand(\"insert_article\",Array(\"3\",\"a3\"))";
_rdc._addcommand /*String*/ ("insert_article",new Object[]{(Object)("3"),(Object)("a3")});
 //BA.debugLineNum = 367;BA.debugLine="wait for (rdc.ExecuteCommands()) complete (Result";
anywheresoftware.b4a.keywords.Common.WaitFor("complete", ba, this, _rdc._executecommands /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ ());
this.state = 37;
return;
case 37:
//C
this.state = 13;
_result = (int) result[0];
;
 //BA.debugLineNum = 368;BA.debugLine="If Result >0 Then	'失敗-1";
if (true) break;

case 13:
//if
this.state = 18;
if (_result>0) { 
this.state = 15;
}else {
this.state = 17;
}if (true) break;

case 15:
//C
this.state = 18;
 //BA.debugLineNum = 369;BA.debugLine="Log(\"新增資料:成功\")";
anywheresoftware.b4a.keywords.Common.LogImpl("35111844","新增資料:成功",0);
 if (true) break;

case 17:
//C
this.state = 18;
 //BA.debugLineNum = 371;BA.debugLine="Log(\"新增資料:失敗\")";
anywheresoftware.b4a.keywords.Common.LogImpl("35111846","新增資料:失敗",0);
 if (true) break;

case 18:
//C
this.state = 19;
;
 //BA.debugLineNum = 374;BA.debugLine="Log(\"查詢資料==>\")";
anywheresoftware.b4a.keywords.Common.LogImpl("35111849","查詢資料==>",0);
 //BA.debugLineNum = 375;BA.debugLine="rdc.ClearCommand";
_rdc._clearcommand /*String*/ ();
 //BA.debugLineNum = 376;BA.debugLine="rdc.AddCommand(\"select_article1\",Array())";
_rdc._addcommand /*String*/ ("select_article1",new Object[]{});
 //BA.debugLineNum = 377;BA.debugLine="wait for (rdc.ExecuteQuery()) complete (Result As";
anywheresoftware.b4a.keywords.Common.WaitFor("complete", ba, this, _rdc._executequery /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ ());
this.state = 38;
return;
case 38:
//C
this.state = 19;
_result = (int) result[0];
;
 //BA.debugLineNum = 378;BA.debugLine="Log(\"row筆數:\"&Result)";
anywheresoftware.b4a.keywords.Common.LogImpl("35111853","row筆數:"+BA.NumberToString(_result),0);
 //BA.debugLineNum = 379;BA.debugLine="If Result >0 Then	'失敗-1";
if (true) break;

case 19:
//if
this.state = 34;
if (_result>0) { 
this.state = 21;
}else {
this.state = 33;
}if (true) break;

case 21:
//C
this.state = 22;
 //BA.debugLineNum = 380;BA.debugLine="Log(\"查詢資料:成功\")";
anywheresoftware.b4a.keywords.Common.LogImpl("35111855","查詢資料:成功",0);
 //BA.debugLineNum = 382;BA.debugLine="Try";
if (true) break;

case 22:
//try
this.state = 31;
this.catchState = 30;
this.state = 24;
if (true) break;

case 24:
//C
this.state = 25;
this.catchState = 30;
 //BA.debugLineNum = 384;BA.debugLine="Dim res As DBResult = rdc.rDBResult";
_res = _rdc._rdbresult /*b4j.example.main._dbresult*/ ;
 //BA.debugLineNum = 385;BA.debugLine="Dim vatNoLst As List";
_vatnolst = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 386;BA.debugLine="vatNoLst.Initialize";
_vatnolst.Initialize();
 //BA.debugLineNum = 387;BA.debugLine="For i=0 To res.Rows.Size-1";
if (true) break;

case 25:
//for
this.state = 28;
step42 = 1;
limit42 = (int) (_res.Rows /*anywheresoftware.b4a.objects.collections.List*/ .getSize()-1);
_i = (int) (0) ;
this.state = 39;
if (true) break;

case 39:
//C
this.state = 28;
if ((step42 > 0 && _i <= limit42) || (step42 < 0 && _i >= limit42)) this.state = 27;
if (true) break;

case 40:
//C
this.state = 39;
_i = ((int)(0 + _i + step42)) ;
if (true) break;

case 27:
//C
this.state = 40;
 //BA.debugLineNum = 388;BA.debugLine="vatNoLst.Add(rdc.GetColumnObject(res,i,\"col2\")";
_vatnolst.Add(_rdc._getcolumnobject /*Object*/ (_res,_i,"col2"));
 //BA.debugLineNum = 390;BA.debugLine="Log(\"col1= \"&rdc.GetColumnObject(res,i,\"col1\")";
anywheresoftware.b4a.keywords.Common.LogImpl("35111865","col1= "+BA.ObjectToString(_rdc._getcolumnobject /*Object*/ (_res,_i,"col1")),0);
 //BA.debugLineNum = 391;BA.debugLine="Log(\"col2= \"&rdc.GetColumnObject(res,i,\"col2\")";
anywheresoftware.b4a.keywords.Common.LogImpl("35111866","col2= "+BA.ObjectToString(_rdc._getcolumnobject /*Object*/ (_res,_i,"col2")),0);
 if (true) break;
if (true) break;

case 28:
//C
this.state = 31;
;
 if (true) break;

case 30:
//C
this.state = 31;
this.catchState = 0;
 //BA.debugLineNum = 394;BA.debugLine="Log(LastException)";
anywheresoftware.b4a.keywords.Common.LogImpl("35111869",BA.ObjectToString(anywheresoftware.b4a.keywords.Common.LastException(ba)),0);
 if (true) break;
if (true) break;

case 31:
//C
this.state = 34;
this.catchState = 0;
;
 //BA.debugLineNum = 397;BA.debugLine="rdc.ExecuteTableView(TableView1)";
_rdc._executetableview /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (parent._tableview1);
 if (true) break;

case 33:
//C
this.state = 34;
 //BA.debugLineNum = 399;BA.debugLine="Log(\"查詢資料:失敗\")";
anywheresoftware.b4a.keywords.Common.LogImpl("35111874","查詢資料:失敗",0);
 if (true) break;

case 34:
//C
this.state = -1;
;
 //BA.debugLineNum = 406;BA.debugLine="End Sub";
if (true) break;
}} 
       catch (Exception e0) {
			
if (catchState == 0)
    throw e0;
else {
    state = catchState;
ba.setLastException(e0);}
            }
        }
    }
}
public static b4j.example.main._dbcommand  _createcommand(String _name,Object[] _parameters) throws Exception{
b4j.example.main._dbcommand _cmd = null;
 //BA.debugLineNum = 46;BA.debugLine="Sub CreateCommand(Name As String, Parameters() As";
 //BA.debugLineNum = 47;BA.debugLine="Dim cmd As DBCommand";
_cmd = new b4j.example.main._dbcommand();
 //BA.debugLineNum = 48;BA.debugLine="cmd.Initialize";
_cmd.Initialize();
 //BA.debugLineNum = 49;BA.debugLine="cmd.Name = Name";
_cmd.Name /*String*/  = _name;
 //BA.debugLineNum = 50;BA.debugLine="If Parameters <> Null Then cmd.Parameters = Param";
if (_parameters!= null) { 
_cmd.Parameters /*Object[]*/  = _parameters;};
 //BA.debugLineNum = 51;BA.debugLine="Return cmd";
if (true) return _cmd;
 //BA.debugLineNum = 52;BA.debugLine="End Sub";
return null;
}
public static b4j.example.dbrequestmanager  _createrequest() throws Exception{
b4j.example.dbrequestmanager _req = null;
 //BA.debugLineNum = 40;BA.debugLine="Sub CreateRequest As DBRequestManager";
 //BA.debugLineNum = 41;BA.debugLine="Dim req As DBRequestManager";
_req = new b4j.example.dbrequestmanager();
 //BA.debugLineNum = 42;BA.debugLine="req.Initialize(Me, rdcLink)";
_req._initialize /*String*/ (ba,main.getObject(),_rdclink);
 //BA.debugLineNum = 43;BA.debugLine="Return req";
if (true) return _req;
 //BA.debugLineNum = 44;BA.debugLine="End Sub";
return null;
}
public static anywheresoftware.b4a.keywords.Common.ResumableSubWrapper  _executetableview(b4j.example.main._dbcommand _cmd) throws Exception{
ResumableSub_ExecuteTableView rsub = new ResumableSub_ExecuteTableView(null,_cmd);
rsub.resume(ba, null);
return (anywheresoftware.b4a.keywords.Common.ResumableSubWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper(), rsub);
}
public static class ResumableSub_ExecuteTableView extends BA.ResumableSub {
public ResumableSub_ExecuteTableView(b4j.example.main parent,b4j.example.main._dbcommand _cmd) {
this.parent = parent;
this._cmd = _cmd;
}
b4j.example.main parent;
b4j.example.main._dbcommand _cmd;
int _result = 0;
b4j.example.main._dbresult _res = null;
anywheresoftware.b4a.objects.collections.List _cols = null;
int _i = 0;
Object[] _row = null;
byte[] _buffer = null;
anywheresoftware.b4a.objects.streams.File.InputStreamWrapper _inputstream1 = null;
anywheresoftware.b4j.objects.ImageViewWrapper.ImageWrapper _bitmap1 = null;
Object[] _urow = null;
anywheresoftware.b4j.objects.LabelWrapper _label1 = null;
anywheresoftware.b4j.objects.LabelWrapper _label2 = null;
anywheresoftware.b4j.objects.ImageViewWrapper _iv1 = null;
int step7;
int limit7;
anywheresoftware.b4a.BA.IterableList group11;
int index11;
int groupLen11;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
{
anywheresoftware.b4a.keywords.Common.ReturnFromResumableSub(this,null);return;}
case 0:
//C
this.state = 1;
 //BA.debugLineNum = 247;BA.debugLine="Dim Result As Int = -1";
_result = (int) (-1);
 //BA.debugLineNum = 248;BA.debugLine="TableView1.Items.Clear";
parent._tableview1.getItems().Clear();
 //BA.debugLineNum = 251;BA.debugLine="Wait For (jRDC2Utils.ExecuteQuery(cmd)) complete";
anywheresoftware.b4a.keywords.Common.WaitFor("complete", ba, this, parent._jrdc2utils._executequery /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ (_cmd));
this.state = 23;
return;
case 23:
//C
this.state = 1;
_res = (b4j.example.main._dbresult) result[0];
;
 //BA.debugLineNum = 252;BA.debugLine="If res <> Null And res.IsInitialized Then";
if (true) break;

case 1:
//if
this.state = 22;
if (_res!= null && _res.IsInitialized /*boolean*/ ) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 253;BA.debugLine="Dim cols As List";
_cols = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 254;BA.debugLine="cols.Initialize";
_cols.Initialize();
 //BA.debugLineNum = 255;BA.debugLine="For i = 0 To res.Columns.Size -1";
if (true) break;

case 4:
//for
this.state = 7;
step7 = 1;
limit7 = (int) (_res.Columns /*anywheresoftware.b4a.objects.collections.Map*/ .getSize()-1);
_i = (int) (0) ;
this.state = 24;
if (true) break;

case 24:
//C
this.state = 7;
if ((step7 > 0 && _i <= limit7) || (step7 < 0 && _i >= limit7)) this.state = 6;
if (true) break;

case 25:
//C
this.state = 24;
_i = ((int)(0 + _i + step7)) ;
if (true) break;

case 6:
//C
this.state = 25;
 //BA.debugLineNum = 256;BA.debugLine="cols.Add(res.Columns.GetKeyAt(i))";
_cols.Add(_res.Columns /*anywheresoftware.b4a.objects.collections.Map*/ .GetKeyAt(_i));
 if (true) break;
if (true) break;

case 7:
//C
this.state = 8;
;
 //BA.debugLineNum = 258;BA.debugLine="TableView1.SetColumns(cols)";
parent._tableview1.SetColumns(_cols);
 //BA.debugLineNum = 259;BA.debugLine="For Each row() As Object In res.Rows";
if (true) break;

case 8:
//for
this.state = 21;
group11 = _res.Rows /*anywheresoftware.b4a.objects.collections.List*/ ;
index11 = 0;
groupLen11 = group11.getSize();
this.state = 26;
if (true) break;

case 26:
//C
this.state = 21;
if (index11 < groupLen11) {
this.state = 10;
_row = (Object[])(group11.Get(index11));}
if (true) break;

case 27:
//C
this.state = 26;
index11++;
if (true) break;

case 10:
//C
this.state = 11;
 //BA.debugLineNum = 261;BA.debugLine="Log(\"row= \"& res.Columns.Get(\"id\"))";
anywheresoftware.b4a.keywords.Common.LogImpl("3393231","row= "+BA.ObjectToString(_res.Columns /*anywheresoftware.b4a.objects.collections.Map*/ .Get((Object)("id"))),0);
 //BA.debugLineNum = 265;BA.debugLine="Private Buffer() As Byte 'declare an empty byte";
_buffer = new byte[(int) (0)];
;
 //BA.debugLineNum = 267;BA.debugLine="Buffer= row(res.Columns.Get(\"image\"))";
_buffer = (byte[])(_row[(int)(BA.ObjectToNumber(_res.Columns /*anywheresoftware.b4a.objects.collections.Map*/ .Get((Object)("image"))))]);
 //BA.debugLineNum = 269;BA.debugLine="If Buffer<>Null Then";
if (true) break;

case 11:
//if
this.state = 20;
if (_buffer!= null) { 
this.state = 13;
}else {
this.state = 19;
}if (true) break;

case 13:
//C
this.state = 14;
 //BA.debugLineNum = 270;BA.debugLine="If Buffer.Length>0 Then";
if (true) break;

case 14:
//if
this.state = 17;
if (_buffer.length>0) { 
this.state = 16;
}if (true) break;

case 16:
//C
this.state = 17;
 //BA.debugLineNum = 273;BA.debugLine="Dim InputStream1 As InputStream";
_inputstream1 = new anywheresoftware.b4a.objects.streams.File.InputStreamWrapper();
 //BA.debugLineNum = 274;BA.debugLine="InputStream1.InitializeFromBytesArray(Buffer,";
_inputstream1.InitializeFromBytesArray(_buffer,(int) (0),_buffer.length);
 //BA.debugLineNum = 275;BA.debugLine="Dim Bitmap1 As Image";
_bitmap1 = new anywheresoftware.b4j.objects.ImageViewWrapper.ImageWrapper();
 //BA.debugLineNum = 276;BA.debugLine="Bitmap1.Initialize2(InputStream1)";
_bitmap1.Initialize2((java.io.InputStream)(_inputstream1.getObject()));
 //BA.debugLineNum = 277;BA.debugLine="InputStream1.Close";
_inputstream1.Close();
 //BA.debugLineNum = 279;BA.debugLine="Dim urow(3) As Object";
_urow = new Object[(int) (3)];
{
int d0 = _urow.length;
for (int i0 = 0;i0 < d0;i0++) {
_urow[i0] = new Object();
}
}
;
 //BA.debugLineNum = 281;BA.debugLine="Dim label1 As Label";
_label1 = new anywheresoftware.b4j.objects.LabelWrapper();
 //BA.debugLineNum = 282;BA.debugLine="label1.Initialize(\"label1\")";
_label1.Initialize(ba,"label1");
 //BA.debugLineNum = 283;BA.debugLine="label1.Text = row(res.Columns.Get(\"name\"))";
_label1.setText(BA.ObjectToString(_row[(int)(BA.ObjectToNumber(_res.Columns /*anywheresoftware.b4a.objects.collections.Map*/ .Get((Object)("name"))))]));
 //BA.debugLineNum = 285;BA.debugLine="Dim label2 As Label";
_label2 = new anywheresoftware.b4j.objects.LabelWrapper();
 //BA.debugLineNum = 286;BA.debugLine="label2.Initialize(\"label1\")";
_label2.Initialize(ba,"label1");
 //BA.debugLineNum = 287;BA.debugLine="label2.Text = row(res.Columns.Get(\"id\"))";
_label2.setText(BA.ObjectToString(_row[(int)(BA.ObjectToNumber(_res.Columns /*anywheresoftware.b4a.objects.collections.Map*/ .Get((Object)("id"))))]));
 //BA.debugLineNum = 289;BA.debugLine="Dim iv1 As ImageView";
_iv1 = new anywheresoftware.b4j.objects.ImageViewWrapper();
 //BA.debugLineNum = 290;BA.debugLine="iv1.Initialize(\"iv1\")";
_iv1.Initialize(ba,"iv1");
 //BA.debugLineNum = 291;BA.debugLine="iv1.SetSize(60,60)";
_iv1.SetSize(60,60);
 //BA.debugLineNum = 292;BA.debugLine="iv1.SetImage(Bitmap1 )";
_iv1.SetImage((javafx.scene.image.Image)(_bitmap1.getObject()));
 //BA.debugLineNum = 295;BA.debugLine="urow(0) = label2";
_urow[(int) (0)] = (Object)(_label2.getObject());
 //BA.debugLineNum = 296;BA.debugLine="urow(1) = label1";
_urow[(int) (1)] = (Object)(_label1.getObject());
 //BA.debugLineNum = 297;BA.debugLine="urow(2) = iv1";
_urow[(int) (2)] = (Object)(_iv1.getObject());
 //BA.debugLineNum = 300;BA.debugLine="TableView1.Items.Add(urow)";
parent._tableview1.getItems().Add((Object)(_urow));
 if (true) break;

case 17:
//C
this.state = 20;
;
 if (true) break;

case 19:
//C
this.state = 20;
 //BA.debugLineNum = 306;BA.debugLine="Dim urow(3) As Object";
_urow = new Object[(int) (3)];
{
int d0 = _urow.length;
for (int i0 = 0;i0 < d0;i0++) {
_urow[i0] = new Object();
}
}
;
 //BA.debugLineNum = 308;BA.debugLine="Dim label1 As Label";
_label1 = new anywheresoftware.b4j.objects.LabelWrapper();
 //BA.debugLineNum = 309;BA.debugLine="label1.Initialize(\"label1\")";
_label1.Initialize(ba,"label1");
 //BA.debugLineNum = 310;BA.debugLine="label1.Text = row(res.Columns.Get(\"name\"))";
_label1.setText(BA.ObjectToString(_row[(int)(BA.ObjectToNumber(_res.Columns /*anywheresoftware.b4a.objects.collections.Map*/ .Get((Object)("name"))))]));
 //BA.debugLineNum = 312;BA.debugLine="Dim label2 As Label";
_label2 = new anywheresoftware.b4j.objects.LabelWrapper();
 //BA.debugLineNum = 313;BA.debugLine="label2.Initialize(\"label1\")";
_label2.Initialize(ba,"label1");
 //BA.debugLineNum = 314;BA.debugLine="label2.Text = row(res.Columns.Get(\"id\"))";
_label2.setText(BA.ObjectToString(_row[(int)(BA.ObjectToNumber(_res.Columns /*anywheresoftware.b4a.objects.collections.Map*/ .Get((Object)("id"))))]));
 //BA.debugLineNum = 317;BA.debugLine="urow(0) = label2";
_urow[(int) (0)] = (Object)(_label2.getObject());
 //BA.debugLineNum = 318;BA.debugLine="urow(1) = label1";
_urow[(int) (1)] = (Object)(_label1.getObject());
 //BA.debugLineNum = 319;BA.debugLine="urow(2) = \"\"";
_urow[(int) (2)] = (Object)("");
 //BA.debugLineNum = 321;BA.debugLine="TableView1.Items.Add(urow)";
parent._tableview1.getItems().Add((Object)(_urow));
 if (true) break;

case 20:
//C
this.state = 27;
;
 if (true) break;
if (true) break;

case 21:
//C
this.state = 22;
;
 //BA.debugLineNum = 326;BA.debugLine="Result = res.Rows.Size";
_result = _res.Rows /*anywheresoftware.b4a.objects.collections.List*/ .getSize();
 if (true) break;

case 22:
//C
this.state = -1;
;
 //BA.debugLineNum = 328;BA.debugLine="Return Result";
if (true) {
anywheresoftware.b4a.keywords.Common.ReturnFromResumableSub(this,(Object)(_result));return;};
 //BA.debugLineNum = 329;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}

private static boolean processGlobalsRun;
public static void initializeProcessGlobals() {
    
    if (main.processGlobalsRun == false) {
	    main.processGlobalsRun = true;
		try {
		        main._process_globals();
jrdc2utils._process_globals();
httputils2service._process_globals();
		
        } catch (Exception e) {
			throw new RuntimeException(e);
		}
    }
}public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 8;BA.debugLine="Type DBResult (Tag As Object, Columns As Map, Row";
;
 //BA.debugLineNum = 9;BA.debugLine="Type DBCommand (Name As String, Parameters() As O";
;
 //BA.debugLineNum = 11;BA.debugLine="Private const rdcLink As String = \"http://127.0.0";
_rdclink = "http://127.0.0.1/rdc";
 //BA.debugLineNum = 16;BA.debugLine="Private fx As JFX";
_fx = new anywheresoftware.b4j.objects.JFX();
 //BA.debugLineNum = 17;BA.debugLine="Private MainForm As Form";
_mainform = new anywheresoftware.b4j.objects.Form();
 //BA.debugLineNum = 18;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 19;BA.debugLine="Private Button1 As B4XView";
_button1 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 20;BA.debugLine="Private TableView1 As TableView";
_tableview1 = new anywheresoftware.b4j.objects.TableViewWrapper();
 //BA.debugLineNum = 21;BA.debugLine="Private Pane1 As B4XView";
_pane1 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 22;BA.debugLine="Private Button2 As B4XView";
_button2 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 23;BA.debugLine="Private Button3 As B4XView";
_button3 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 24;BA.debugLine="End Sub";
return "";
}
}
