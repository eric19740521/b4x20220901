package b4j.example;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class xyzrdc2 extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.xyzrdc2", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.example.xyzrdc2.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public String _rdclink = "";
public anywheresoftware.b4a.objects.collections.List _cmdlst = null;
public b4j.example.main._dbresult _rdbresult = null;
public String _errormessage = "";
public b4j.example.main _main = null;
public b4j.example.jrdc2utils _jrdc2utils = null;
public b4j.example.httputils2service _httputils2service = null;
public String  _addcommand(String _cmd,Object[] _params) throws Exception{
 //BA.debugLineNum = 89;BA.debugLine="Public Sub AddCommand(cmd As String, params() As O";
 //BA.debugLineNum = 90;BA.debugLine="cmdLst.Add(CreateCommand(cmd, params))";
_cmdlst.Add((Object)(_createcommand(_cmd,_params)));
 //BA.debugLineNum = 91;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 10;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 14;BA.debugLine="Private rdcLink As String";
_rdclink = "";
 //BA.debugLineNum = 15;BA.debugLine="Private cmdLst As List";
_cmdlst = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 17;BA.debugLine="Public rDBResult As DBResult";
_rdbresult = new b4j.example.main._dbresult();
 //BA.debugLineNum = 18;BA.debugLine="Public ErrorMessage As String";
_errormessage = "";
 //BA.debugLineNum = 20;BA.debugLine="End Sub";
return "";
}
public String  _clearcommand() throws Exception{
 //BA.debugLineNum = 85;BA.debugLine="Public Sub ClearCommand()";
 //BA.debugLineNum = 86;BA.debugLine="cmdLst.Clear";
_cmdlst.Clear();
 //BA.debugLineNum = 87;BA.debugLine="rDBResult = Null";
_rdbresult = (b4j.example.main._dbresult)(__c.Null);
 //BA.debugLineNum = 88;BA.debugLine="End Sub";
return "";
}
public b4j.example.main._dbcommand  _createcommand(String _name,Object[] _parameters) throws Exception{
b4j.example.main._dbcommand _cmd = null;
 //BA.debugLineNum = 36;BA.debugLine="Private Sub CreateCommand(Name As String, Paramete";
 //BA.debugLineNum = 37;BA.debugLine="Dim cmd As DBCommand";
_cmd = new b4j.example.main._dbcommand();
 //BA.debugLineNum = 38;BA.debugLine="cmd.Initialize";
_cmd.Initialize();
 //BA.debugLineNum = 39;BA.debugLine="cmd.Name = Name";
_cmd.Name /*String*/  = _name;
 //BA.debugLineNum = 40;BA.debugLine="If Parameters <> Null Then cmd.Parameters = Param";
if (_parameters!= null) { 
_cmd.Parameters /*Object[]*/  = _parameters;};
 //BA.debugLineNum = 41;BA.debugLine="Return cmd";
if (true) return _cmd;
 //BA.debugLineNum = 42;BA.debugLine="End Sub";
return null;
}
public b4j.example.dbrequestmanager  _createrequest() throws Exception{
b4j.example.dbrequestmanager _req = null;
 //BA.debugLineNum = 30;BA.debugLine="Private Sub CreateRequest As DBRequestManager";
 //BA.debugLineNum = 31;BA.debugLine="Dim req As DBRequestManager";
_req = new b4j.example.dbrequestmanager();
 //BA.debugLineNum = 32;BA.debugLine="req.Initialize(Me, rdcLink)";
_req._initialize /*String*/ (ba,this,_rdclink);
 //BA.debugLineNum = 33;BA.debugLine="Return req";
if (true) return _req;
 //BA.debugLineNum = 34;BA.debugLine="End Sub";
return null;
}
public anywheresoftware.b4a.keywords.Common.ResumableSubWrapper  _executecommands() throws Exception{
ResumableSub_ExecuteCommands rsub = new ResumableSub_ExecuteCommands(this);
rsub.resume(ba, null);
return (anywheresoftware.b4a.keywords.Common.ResumableSubWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper(), rsub);
}
public static class ResumableSub_ExecuteCommands extends BA.ResumableSub {
public ResumableSub_ExecuteCommands(b4j.example.xyzrdc2 parent) {
this.parent = parent;
}
b4j.example.xyzrdc2 parent;
int _cmdcount = 0;
b4j.example.httpjob _j = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
{
parent.__c.ReturnFromResumableSub(this,null);return;}
case 0:
//C
this.state = 1;
 //BA.debugLineNum = 94;BA.debugLine="Dim cmdCount As Int = -1";
_cmdcount = (int) (-1);
 //BA.debugLineNum = 96;BA.debugLine="If cmdLst.Size > 0 Then";
if (true) break;

case 1:
//if
this.state = 10;
if (parent._cmdlst.getSize()>0) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 97;BA.debugLine="Dim j As HttpJob = CreateRequest.ExecuteBatch(cm";
_j = parent._createrequest()._executebatch /*b4j.example.httpjob*/ (parent._cmdlst,parent.__c.Null);
 //BA.debugLineNum = 98;BA.debugLine="Wait For(j) JobDone(j As HttpJob)";
parent.__c.WaitFor("jobdone", ba, this, (Object)(_j));
this.state = 11;
return;
case 11:
//C
this.state = 4;
_j = (b4j.example.httpjob) result[0];
;
 //BA.debugLineNum = 99;BA.debugLine="If j.Success Then";
if (true) break;

case 4:
//if
this.state = 9;
if (_j._success /*boolean*/ ) { 
this.state = 6;
}else {
this.state = 8;
}if (true) break;

case 6:
//C
this.state = 9;
 //BA.debugLineNum = 100;BA.debugLine="cmdCount = cmdLst.Size";
_cmdcount = parent._cmdlst.getSize();
 if (true) break;

case 8:
//C
this.state = 9;
 //BA.debugLineNum = 102;BA.debugLine="Log($\"Error executing command: ${j.ErrorMessage";
parent.__c.LogImpl("34718601",("Error executing command: "+parent.__c.SmartStringFormatter("",(Object)(_j._errormessage /*String*/ ))+""),0);
 if (true) break;

case 9:
//C
this.state = 10;
;
 //BA.debugLineNum = 104;BA.debugLine="j.Release";
_j._release /*String*/ ();
 if (true) break;

case 10:
//C
this.state = -1;
;
 //BA.debugLineNum = 106;BA.debugLine="Return cmdCount";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(_cmdcount));return;};
 //BA.debugLineNum = 107;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _jobdone(b4j.example.httpjob _j) throws Exception{
}
public anywheresoftware.b4a.keywords.Common.ResumableSubWrapper  _executequery() throws Exception{
ResumableSub_ExecuteQuery rsub = new ResumableSub_ExecuteQuery(this);
rsub.resume(ba, null);
return (anywheresoftware.b4a.keywords.Common.ResumableSubWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper(), rsub);
}
public static class ResumableSub_ExecuteQuery extends BA.ResumableSub {
public ResumableSub_ExecuteQuery(b4j.example.xyzrdc2 parent) {
this.parent = parent;
}
b4j.example.xyzrdc2 parent;
b4j.example.dbrequestmanager _req = null;
int _cmdcount = 0;
b4j.example.main._dbcommand _cmd = null;
b4j.example.httpjob _j = null;
b4j.example.main._dbresult _res = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
{
parent.__c.ReturnFromResumableSub(this,null);return;}
case 0:
//C
this.state = 1;
 //BA.debugLineNum = 111;BA.debugLine="Log(\"xyzRDC2 ExecuteQuery==>\")";
parent.__c.LogImpl("35242881","xyzRDC2 ExecuteQuery==>",0);
 //BA.debugLineNum = 113;BA.debugLine="Dim req As DBRequestManager = CreateRequest";
_req = parent._createrequest();
 //BA.debugLineNum = 115;BA.debugLine="Dim cmdCount As Int = -1";
_cmdcount = (int) (-1);
 //BA.debugLineNum = 116;BA.debugLine="If cmdLst.Size = 0 Then";
if (true) break;

case 1:
//if
this.state = 4;
if (parent._cmdlst.getSize()==0) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 118;BA.debugLine="rDBResult = Null";
parent._rdbresult = (b4j.example.main._dbresult)(parent.__c.Null);
 //BA.debugLineNum = 120;BA.debugLine="Return cmdCount";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(_cmdcount));return;};
 if (true) break;

case 4:
//C
this.state = 5;
;
 //BA.debugLineNum = 123;BA.debugLine="Dim cmd As DBCommand = cmdLst.GET(0)";
_cmd = (b4j.example.main._dbcommand)(parent._cmdlst.Get((int) (0)));
 //BA.debugLineNum = 125;BA.debugLine="Wait For (req.ExecuteQuery(cmd, 0, Null)) JobDone";
parent.__c.WaitFor("jobdone", ba, this, (Object)(_req._executequery /*b4j.example.httpjob*/ (_cmd,(int) (0),parent.__c.Null)));
this.state = 15;
return;
case 15:
//C
this.state = 5;
_j = (b4j.example.httpjob) result[0];
;
 //BA.debugLineNum = 126;BA.debugLine="If j.Success Then";
if (true) break;

case 5:
//if
this.state = 14;
if (_j._success /*boolean*/ ) { 
this.state = 7;
}else {
this.state = 13;
}if (true) break;

case 7:
//C
this.state = 8;
 //BA.debugLineNum = 128;BA.debugLine="Log(\"JobDone OK...\")";
parent.__c.LogImpl("35242898","JobDone OK...",0);
 //BA.debugLineNum = 129;BA.debugLine="cmdCount = 1";
_cmdcount = (int) (1);
 //BA.debugLineNum = 131;BA.debugLine="req.HandleJobAsync(j, \"req\")";
_req._handlejobasync /*void*/ (_j,"req");
 //BA.debugLineNum = 132;BA.debugLine="If SubExists(Me, \"req_Result\") Then";
if (true) break;

case 8:
//if
this.state = 11;
if (parent.__c.SubExists(ba,parent,"req_Result")) { 
this.state = 10;
}if (true) break;

case 10:
//C
this.state = 11;
 //BA.debugLineNum = 133;BA.debugLine="Log($\"Going to call Sub \"req_Result\" ...\"$)";
parent.__c.LogImpl("35242903",("Going to call Sub \"req_Result\" ..."),0);
 if (true) break;

case 11:
//C
this.state = 14;
;
 //BA.debugLineNum = 135;BA.debugLine="Wait For (req) req_result(res As DBResult)			'##";
parent.__c.WaitFor("req_result", ba, this, (Object)(_req));
this.state = 16;
return;
case 16:
//C
this.state = 14;
_res = (b4j.example.main._dbresult) result[0];
;
 //BA.debugLineNum = 136;BA.debugLine="rDBResult = res";
parent._rdbresult = _res;
 //BA.debugLineNum = 137;BA.debugLine="cmdCount = rDBResult.Rows.Size 	'傳回紀錄筆數";
_cmdcount = parent._rdbresult.Rows /*anywheresoftware.b4a.objects.collections.List*/ .getSize();
 if (true) break;

case 13:
//C
this.state = 14;
 //BA.debugLineNum = 140;BA.debugLine="rDBResult = Null";
parent._rdbresult = (b4j.example.main._dbresult)(parent.__c.Null);
 //BA.debugLineNum = 141;BA.debugLine="ErrorMessage = j.ErrorMessage";
parent._errormessage = _j._errormessage /*String*/ ;
 if (true) break;

case 14:
//C
this.state = -1;
;
 //BA.debugLineNum = 144;BA.debugLine="j.Release";
_j._release /*String*/ ();
 //BA.debugLineNum = 146;BA.debugLine="Return cmdCount";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(_cmdcount));return;};
 //BA.debugLineNum = 147;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _req_result(b4j.example.main._dbresult _res) throws Exception{
}
public anywheresoftware.b4a.keywords.Common.ResumableSubWrapper  _executetableview(anywheresoftware.b4j.objects.TableViewWrapper _tableview1) throws Exception{
ResumableSub_ExecuteTableView rsub = new ResumableSub_ExecuteTableView(this,_tableview1);
rsub.resume(ba, null);
return (anywheresoftware.b4a.keywords.Common.ResumableSubWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper(), rsub);
}
public static class ResumableSub_ExecuteTableView extends BA.ResumableSub {
public ResumableSub_ExecuteTableView(b4j.example.xyzrdc2 parent,anywheresoftware.b4j.objects.TableViewWrapper _tableview1) {
this.parent = parent;
this._tableview1 = _tableview1;
}
b4j.example.xyzrdc2 parent;
anywheresoftware.b4j.objects.TableViewWrapper _tableview1;
int _result = 0;
int _result0 = 0;
b4j.example.main._dbresult _res = null;
anywheresoftware.b4a.objects.collections.List _cols = null;
int _i = 0;
Object[] _row = null;
String[] _values = null;
String _value = "";
int _col = 0;
int step8;
int limit8;
anywheresoftware.b4a.BA.IterableList group12;
int index12;
int groupLen12;
int step15;
int limit15;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
{
parent.__c.ReturnFromResumableSub(this,null);return;}
case 0:
//C
this.state = 1;
 //BA.debugLineNum = 190;BA.debugLine="Dim Result As Int = -1";
_result = (int) (-1);
 //BA.debugLineNum = 201;BA.debugLine="TableView1.Items.Clear";
_tableview1.getItems().Clear();
 //BA.debugLineNum = 202;BA.debugLine="Wait For (ExecuteQuery) complete (Result0 As Int)";
parent.__c.WaitFor("complete", ba, this, parent._executequery());
this.state = 17;
return;
case 17:
//C
this.state = 1;
_result0 = (int) result[0];
;
 //BA.debugLineNum = 203;BA.debugLine="Dim res As DBResult = rDBResult";
_res = parent._rdbresult;
 //BA.debugLineNum = 204;BA.debugLine="If res <> Null And res.IsInitialized Then";
if (true) break;

case 1:
//if
this.state = 16;
if (_res!= null && _res.IsInitialized /*boolean*/ ) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 205;BA.debugLine="Dim cols As List";
_cols = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 206;BA.debugLine="cols.Initialize";
_cols.Initialize();
 //BA.debugLineNum = 207;BA.debugLine="For i = 0 To res.Columns.Size -1";
if (true) break;

case 4:
//for
this.state = 7;
step8 = 1;
limit8 = (int) (_res.Columns /*anywheresoftware.b4a.objects.collections.Map*/ .getSize()-1);
_i = (int) (0) ;
this.state = 18;
if (true) break;

case 18:
//C
this.state = 7;
if ((step8 > 0 && _i <= limit8) || (step8 < 0 && _i >= limit8)) this.state = 6;
if (true) break;

case 19:
//C
this.state = 18;
_i = ((int)(0 + _i + step8)) ;
if (true) break;

case 6:
//C
this.state = 19;
 //BA.debugLineNum = 208;BA.debugLine="cols.Add(res.Columns.GetKeyAt(i))";
_cols.Add(_res.Columns /*anywheresoftware.b4a.objects.collections.Map*/ .GetKeyAt(_i));
 if (true) break;
if (true) break;

case 7:
//C
this.state = 8;
;
 //BA.debugLineNum = 210;BA.debugLine="TableView1.SetColumns(cols)";
_tableview1.SetColumns(_cols);
 //BA.debugLineNum = 211;BA.debugLine="For Each row() As Object In res.Rows";
if (true) break;

case 8:
//for
this.state = 15;
group12 = _res.Rows /*anywheresoftware.b4a.objects.collections.List*/ ;
index12 = 0;
groupLen12 = group12.getSize();
this.state = 20;
if (true) break;

case 20:
//C
this.state = 15;
if (index12 < groupLen12) {
this.state = 10;
_row = (Object[])(group12.Get(index12));}
if (true) break;

case 21:
//C
this.state = 20;
index12++;
if (true) break;

case 10:
//C
this.state = 11;
 //BA.debugLineNum = 212;BA.debugLine="Dim values(res.Columns.Size) As String";
_values = new String[_res.Columns /*anywheresoftware.b4a.objects.collections.Map*/ .getSize()];
java.util.Arrays.fill(_values,"");
 //BA.debugLineNum = 213;BA.debugLine="Dim value As String";
_value = "";
 //BA.debugLineNum = 214;BA.debugLine="For col = 0 To res.Columns.Size - 1";
if (true) break;

case 11:
//for
this.state = 14;
step15 = 1;
limit15 = (int) (_res.Columns /*anywheresoftware.b4a.objects.collections.Map*/ .getSize()-1);
_col = (int) (0) ;
this.state = 22;
if (true) break;

case 22:
//C
this.state = 14;
if ((step15 > 0 && _col <= limit15) || (step15 < 0 && _col >= limit15)) this.state = 13;
if (true) break;

case 23:
//C
this.state = 22;
_col = ((int)(0 + _col + step15)) ;
if (true) break;

case 13:
//C
this.state = 23;
 //BA.debugLineNum = 215;BA.debugLine="value = row(col)";
_value = BA.ObjectToString(_row[_col]);
 //BA.debugLineNum = 216;BA.debugLine="values(col) = value";
_values[_col] = _value;
 if (true) break;
if (true) break;

case 14:
//C
this.state = 21;
;
 //BA.debugLineNum = 218;BA.debugLine="TableView1.Items.Add(values)";
_tableview1.getItems().Add((Object)(_values));
 if (true) break;
if (true) break;

case 15:
//C
this.state = 16;
;
 //BA.debugLineNum = 220;BA.debugLine="Result = res.Rows.Size";
_result = _res.Rows /*anywheresoftware.b4a.objects.collections.List*/ .getSize();
 if (true) break;

case 16:
//C
this.state = -1;
;
 //BA.debugLineNum = 222;BA.debugLine="Return Result";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(_result));return;};
 //BA.debugLineNum = 223;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _complete(int _result0) throws Exception{
}
public int  _getcolumnindex(b4j.example.main._dbresult _res,String _colname) throws Exception{
int _colidx = 0;
anywheresoftware.b4a.objects.collections.Map _columns = null;
String _key = "";
 //BA.debugLineNum = 173;BA.debugLine="Public Sub GetColumnIndex(res As DBResult, colName";
 //BA.debugLineNum = 174;BA.debugLine="Dim colIdx As Int = -1";
_colidx = (int) (-1);
 //BA.debugLineNum = 176;BA.debugLine="Dim columns As Map = res.Columns";
_columns = new anywheresoftware.b4a.objects.collections.Map();
_columns = _res.Columns /*anywheresoftware.b4a.objects.collections.Map*/ ;
 //BA.debugLineNum = 177;BA.debugLine="For Each key As String In columns.Keys";
{
final anywheresoftware.b4a.BA.IterableList group3 = _columns.Keys();
final int groupLen3 = group3.getSize()
;int index3 = 0;
;
for (; index3 < groupLen3;index3++){
_key = BA.ObjectToString(group3.Get(index3));
 //BA.debugLineNum = 178;BA.debugLine="If key.EqualsIgnoreCase(colName) Then";
if (_key.equalsIgnoreCase(_colname)) { 
 //BA.debugLineNum = 179;BA.debugLine="colIdx = columns.Get(key)";
_colidx = (int)(BA.ObjectToNumber(_columns.Get((Object)(_key))));
 //BA.debugLineNum = 180;BA.debugLine="Exit";
if (true) break;
 };
 }
};
 //BA.debugLineNum = 183;BA.debugLine="Return colIdx";
if (true) return _colidx;
 //BA.debugLineNum = 184;BA.debugLine="End Sub";
return 0;
}
public Object  _getcolumnobject(b4j.example.main._dbresult _res,int _rowidx,String _colname) throws Exception{
int _colidx = 0;
anywheresoftware.b4a.objects.collections.Map _columns = null;
String _key = "";
Object[] _row = null;
 //BA.debugLineNum = 155;BA.debugLine="Public Sub GetColumnObject(res As DBResult, rowIdx";
 //BA.debugLineNum = 160;BA.debugLine="Dim colIdx As Int = -1";
_colidx = (int) (-1);
 //BA.debugLineNum = 161;BA.debugLine="Dim columns As Map = res.Columns";
_columns = new anywheresoftware.b4a.objects.collections.Map();
_columns = _res.Columns /*anywheresoftware.b4a.objects.collections.Map*/ ;
 //BA.debugLineNum = 162;BA.debugLine="For Each key As String In columns.Keys";
{
final anywheresoftware.b4a.BA.IterableList group3 = _columns.Keys();
final int groupLen3 = group3.getSize()
;int index3 = 0;
;
for (; index3 < groupLen3;index3++){
_key = BA.ObjectToString(group3.Get(index3));
 //BA.debugLineNum = 163;BA.debugLine="If key.EqualsIgnoreCase(colName) Then";
if (_key.equalsIgnoreCase(_colname)) { 
 //BA.debugLineNum = 164;BA.debugLine="colIdx = columns.Get(key)";
_colidx = (int)(BA.ObjectToNumber(_columns.Get((Object)(_key))));
 //BA.debugLineNum = 165;BA.debugLine="Exit";
if (true) break;
 };
 }
};
 //BA.debugLineNum = 168;BA.debugLine="If colIdx = -1 Then Return Null";
if (_colidx==-1) { 
if (true) return __c.Null;};
 //BA.debugLineNum = 169;BA.debugLine="Dim row() As Object = res.Rows.Get(rowIdx)";
_row = (Object[])(_res.Rows /*anywheresoftware.b4a.objects.collections.List*/ .Get(_rowidx));
 //BA.debugLineNum = 170;BA.debugLine="Return row(colIdx)";
if (true) return _row[_colidx];
 //BA.debugLineNum = 171;BA.debugLine="End Sub";
return null;
}
public anywheresoftware.b4a.keywords.Common.ResumableSubWrapper  _getrecord(String _command,String[] _parameters) throws Exception{
ResumableSub_GetRecord rsub = new ResumableSub_GetRecord(this,_command,_parameters);
rsub.resume(ba, null);
return (anywheresoftware.b4a.keywords.Common.ResumableSubWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper(), rsub);
}
public static class ResumableSub_GetRecord extends BA.ResumableSub {
public ResumableSub_GetRecord(b4j.example.xyzrdc2 parent,String _command,String[] _parameters) {
this.parent = parent;
this._command = _command;
this._parameters = _parameters;
}
b4j.example.xyzrdc2 parent;
String _command;
String[] _parameters;
anywheresoftware.b4a.objects.collections.Map _answer = null;
b4j.example.dbrequestmanager _req = null;
b4j.example.main._dbcommand _cmd = null;
b4j.example.httpjob _j = null;
b4j.example.main._dbresult _res = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
{
parent.__c.ReturnFromResumableSub(this,null);return;}
case 0:
//C
this.state = 1;
 //BA.debugLineNum = 45;BA.debugLine="Dim Answer As Map";
_answer = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 46;BA.debugLine="Answer.Initialize";
_answer.Initialize();
 //BA.debugLineNum = 47;BA.debugLine="Dim req As DBRequestManager = CreateRequest";
_req = parent._createrequest();
 //BA.debugLineNum = 48;BA.debugLine="Dim cmd As DBCommand = CreateCommand(Command, par";
_cmd = parent._createcommand(_command,(Object[])(_parameters));
 //BA.debugLineNum = 49;BA.debugLine="Wait For (req.ExecuteQuery(cmd, 0, Null)) JobDone";
parent.__c.WaitFor("jobdone", ba, this, (Object)(_req._executequery /*b4j.example.httpjob*/ (_cmd,(int) (0),parent.__c.Null)));
this.state = 7;
return;
case 7:
//C
this.state = 1;
_j = (b4j.example.httpjob) result[0];
;
 //BA.debugLineNum = 50;BA.debugLine="Answer.Put(\"Success\", j.Success)";
_answer.Put((Object)("Success"),(Object)(_j._success /*boolean*/ ));
 //BA.debugLineNum = 51;BA.debugLine="If j.Success Then";
if (true) break;

case 1:
//if
this.state = 6;
if (_j._success /*boolean*/ ) { 
this.state = 3;
}else {
this.state = 5;
}if (true) break;

case 3:
//C
this.state = 6;
 //BA.debugLineNum = 52;BA.debugLine="req.HandleJobAsync(j, \"req\")";
_req._handlejobasync /*void*/ (_j,"req");
 //BA.debugLineNum = 53;BA.debugLine="Wait For (req) req_Result(Res As DBResult)";
parent.__c.WaitFor("req_result", ba, this, (Object)(_req));
this.state = 8;
return;
case 8:
//C
this.state = 6;
_res = (b4j.example.main._dbresult) result[0];
;
 //BA.debugLineNum = 55;BA.debugLine="req.PrintTable(Res)";
_req._printtable /*String*/ (_res);
 //BA.debugLineNum = 56;BA.debugLine="Answer.Put(\"Message\",\"Data have been read succes";
_answer.Put((Object)("Message"),(Object)("Data have been read successfully"));
 if (true) break;

case 5:
//C
this.state = 6;
 //BA.debugLineNum = 58;BA.debugLine="Log(\"ERROR: \" & j.ErrorMessage)";
parent.__c.LogImpl("34521998","ERROR: "+_j._errormessage /*String*/ ,0);
 //BA.debugLineNum = 59;BA.debugLine="Answer.Put(\"Error\", j.ErrorMessage)";
_answer.Put((Object)("Error"),(Object)(_j._errormessage /*String*/ ));
 if (true) break;

case 6:
//C
this.state = -1;
;
 //BA.debugLineNum = 61;BA.debugLine="j.Release";
_j._release /*String*/ ();
 //BA.debugLineNum = 62;BA.debugLine="Answer.Put(\"Data\",Res)";
_answer.Put((Object)("Data"),(Object)(_res));
 //BA.debugLineNum = 64;BA.debugLine="Return Answer";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(_answer));return;};
 //BA.debugLineNum = 65;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public String  _initialize(anywheresoftware.b4a.BA _ba,String _rdcuri) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 23;BA.debugLine="Public Sub Initialize(rdcUri As String)";
 //BA.debugLineNum = 24;BA.debugLine="rdcLink = rdcUri";
_rdclink = _rdcuri;
 //BA.debugLineNum = 26;BA.debugLine="cmdLst.Initialize";
_cmdlst.Initialize();
 //BA.debugLineNum = 27;BA.debugLine="rDBResult = Null";
_rdbresult = (b4j.example.main._dbresult)(__c.Null);
 //BA.debugLineNum = 28;BA.debugLine="End Sub";
return "";
}
public anywheresoftware.b4a.keywords.Common.ResumableSubWrapper  _insertupdaterecord(String _command,String[] _parameters) throws Exception{
ResumableSub_InsertUpdateRecord rsub = new ResumableSub_InsertUpdateRecord(this,_command,_parameters);
rsub.resume(ba, null);
return (anywheresoftware.b4a.keywords.Common.ResumableSubWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper(), rsub);
}
public static class ResumableSub_InsertUpdateRecord extends BA.ResumableSub {
public ResumableSub_InsertUpdateRecord(b4j.example.xyzrdc2 parent,String _command,String[] _parameters) {
this.parent = parent;
this._command = _command;
this._parameters = _parameters;
}
b4j.example.xyzrdc2 parent;
String _command;
String[] _parameters;
anywheresoftware.b4a.objects.collections.Map _answer = null;
b4j.example.main._dbcommand _cmd = null;
b4j.example.httpjob _j = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
{
parent.__c.ReturnFromResumableSub(this,null);return;}
case 0:
//C
this.state = 1;
 //BA.debugLineNum = 68;BA.debugLine="Dim Answer As Map";
_answer = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 69;BA.debugLine="Answer.Initialize";
_answer.Initialize();
 //BA.debugLineNum = 70;BA.debugLine="Dim cmd As DBCommand = CreateCommand(Command, par";
_cmd = parent._createcommand(_command,(Object[])(_parameters));
 //BA.debugLineNum = 71;BA.debugLine="Dim j As HttpJob = CreateRequest.ExecuteBatch(Arr";
_j = parent._createrequest()._executebatch /*b4j.example.httpjob*/ (anywheresoftware.b4a.keywords.Common.ArrayToList(new Object[]{(Object)(_cmd)}),parent.__c.Null);
 //BA.debugLineNum = 72;BA.debugLine="Wait For(j) JobDone(j As HttpJob)";
parent.__c.WaitFor("jobdone", ba, this, (Object)(_j));
this.state = 5;
return;
case 5:
//C
this.state = 1;
_j = (b4j.example.httpjob) result[0];
;
 //BA.debugLineNum = 73;BA.debugLine="If j.Success Then";
if (true) break;

case 1:
//if
this.state = 4;
if (_j._success /*boolean*/ ) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 74;BA.debugLine="Log(\"successfully!\")";
parent.__c.LogImpl("34587527","successfully!",0);
 if (true) break;

case 4:
//C
this.state = -1;
;
 //BA.debugLineNum = 76;BA.debugLine="Answer.Put(\"Success\",j.Success)";
_answer.Put((Object)("Success"),(Object)(_j._success /*boolean*/ ));
 //BA.debugLineNum = 77;BA.debugLine="Answer.Put(\"Error\", j.ErrorMessage)";
_answer.Put((Object)("Error"),(Object)(_j._errormessage /*String*/ ));
 //BA.debugLineNum = 78;BA.debugLine="j.Release";
_j._release /*String*/ ();
 //BA.debugLineNum = 79;BA.debugLine="Return Answer";
if (true) {
parent.__c.ReturnFromResumableSub(this,(Object)(_answer));return;};
 //BA.debugLineNum = 80;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
