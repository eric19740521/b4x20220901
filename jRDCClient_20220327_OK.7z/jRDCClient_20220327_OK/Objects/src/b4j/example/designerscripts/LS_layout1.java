package b4j.example.designerscripts;
import anywheresoftware.b4a.BA;


public class LS_layout1{

public static void LS_general(anywheresoftware.b4a.BA ba, javafx.scene.Node parent, anywheresoftware.b4j.objects.LayoutValues lv,
anywheresoftware.b4j.objects.LayoutBuilder.LayoutData views, int width, int height, float scale)  throws Exception  {
;
//BA.debugLineNum = 7;BA.debugLine="TableView1.SetTopAndBottom(Pane1.Bottom+5dip,100%y-10dip)"[Layout1/General script]
views.get("tableview1").setTop((int)((views.get("pane1").getTop() + views.get("pane1").getPrefHeight())+(5d * scale)));
views.get("tableview1").setPrefHeight((int)((100d / 100 * height)-(10d * scale) - ((views.get("pane1").getTop() + views.get("pane1").getPrefHeight())+(5d * scale))));

}
}